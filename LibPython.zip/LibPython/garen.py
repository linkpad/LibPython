import SDK
import math

class menu: pass
class spell: pass

def OnLoad():
	SDK.GGame().PrintChat("Loaded PythonGaren")
	CreateMenu()
	loadSpell()

def CreateMenu():
	menu.mainMenu = SDK.GPluginSDK().AddMenu("PythonGaren - Example Script")
	menu.drawMenu = menu.mainMenu.AddMenu(">> Drawings <<")
	menu.drawE = menu.drawMenu.CheckBox("Draw (E)", True)
	menu.drawR = menu.drawMenu.CheckBox("Draw (R)", True)
	menu.LaneClear = menu.mainMenu.AddMenu(">> LaneClear <<")
	menu.clearQ = menu.LaneClear.CheckBox("Use (Q)", True)
	menu.clearE = menu.LaneClear.CheckBox("Use (E)", True)

def loadSpell():
	spell.Q = SDK.GPluginSDK().CreateSpell2(SDK.kSlotQ, SDK.kTargetCast, False, False, SDK.kCollidesWithNothing)
	spell.E = SDK.GPluginSDK().CreateSpell2(SDK.kSlotE, SDK.kTargetCast, False, True, SDK.kCollidesWithNothing)
	spell.R = SDK.GPluginSDK().CreateSpell2(SDK.kSlotR, SDK.kTargetCast, False, False, SDK.kCollidesWithNothing)

def OnUnload():
	menu.mainMenu.Remove()

def OnRender():
	if menu.drawE.Enabled() == True:
		SDK.GRender().DrawOutlinedCircle(SDK.GEntityList().Player().GetPosition(), SDK.Vec4(0.0, 200.0, 100.0, 100.0), spell.E.Range())
	if menu.drawR.Enabled() == True:
		SDK.GRender().DrawOutlinedCircle(SDK.GEntityList().Player().GetPosition(), SDK.Vec4(0.0, 200.0, 100.0, 100.0), spell.R.Range())

def OnGameUpdate():
	if SDK.GOrbwalking().GetOrbwalkingMode() == SDK.kModeLaneClear:
		LaneClear()

def LaneClear():
	enemyMinion = GetMinions(300.0)
	myPos = SDK.GEntityList().Player().GetPosition()
	for minion in enemyMinion:
		if minion.IsValidObject() and not minion.IsDead() and minion.IsTargetable() and minion.IsCreep() and minion.IsVisible():
			if menu.clearE.Enabled() == True:
				if spell.E.IsReady() and len(enemyMinion) >= 3:
					spell.E.CastOnPlayer()
			if menu.clearQ.Enabled() == True:
				if spell.Q.IsReady() and GetDistance(myPos, minion.GetPosition()) < spell.Q.Range():
					spell.Q.CastOnUnit(minion)


def GetMinions(distance):
	enemyMinion = list(SDK.GEntityList().GetAllMinions(False, True, False))
	foundMinion = list()
	myPos = SDK.GEntityList().Player().GetPosition()
	for minion in enemyMinion:
		if GetDistance(myPos, minion.GetPosition()) < distance and minion.IsEnemy(SDK.GEntityList().Player()):
			foundMinion.append(minion)
	return foundMinion

def GetDistance(start, end):
	x1 = start.x
	y1 = start.y
	z1 = start.z
	x2 = end.x
	y2 = end.y
	z2 = end.z
	distance = math.sqrt(pow((x2 - x1), 2.0) + pow((y2 - y1), 2.0) + pow((z2 - z1), 2.0))
	return distance